package com.railse.hiring.workforcemgmt.model.enums;

public enum Priority {
LOW,
MEDIUM,
HIGH
}